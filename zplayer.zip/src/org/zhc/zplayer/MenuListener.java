package org.zhc.zplayer;

//歌曲分组重命名监听器
public interface MenuListener{
	
  public void changed(String old,String newv);
  
}
